Aplikacia sluzi na simulaciu pohybu autobusov na mape. Tieto autobusy sa riadia podla danych odchodov zo zastavok. Kazdy autobus ma rovnaku rychlost, ktora moze byt ovplyvnena ztazenymi dopravnymi podmienkami na danej ulici. Odchody zo zastavok sa nasledne prepocitaju a zafarbia na cerveno. Uzivatel tiez moze upravit cestu danej linky, pricom odchod z prvej zastavky zostava rovnaky aj v upravenej trase linky.

Autori: Dominik Vagala (xvagal00), Jakub Vinš (xvinsj00)
