wget http://www.java2s.com/Code/JarDownload/json-simple/json-simple-1.1.jar.zip

unzip json-simple-1.1.jar.zip

rm json-simple-1.1.jar.zip

